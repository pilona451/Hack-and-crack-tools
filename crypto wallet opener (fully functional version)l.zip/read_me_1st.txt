------------

Just run the .exe file

Good luck hunting!